

<nav class="navbar navbar-default">
				
    <div class="navbar-header">
        <!-- 모바일 토글 메뉴 버튼 -->
        <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
        <a class="navbar-brand" href="index.php">myBooks</a> 
    </div>

    <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php" class="external"><span>Home</span></a></li>
            <li><a href="showBookShelf.php"  class="external"><span>My books</span></a></li>
            <!-- <li><a href="signin.php" class="external"><span>Sign In</span></a></li> -->
            <li><a href="signup.php" class="external"><span>Join</span></a></li>
            <li><a href="index.php" class="external"><span>Search</span></a></li>
        </ul>
    </div>
    

    

</nav>
