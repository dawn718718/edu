<?
    $conn = new mysqli("localhost","root","1111","testdb");
    if($conn->connect_error){
        die("연결실패".$conn->connect_error);
    };
    mysqli_set_charset($conn,"utf8");
    $sql = "UPDATE student SET NAME="나나나" WHERE student_id = 19050001";
    $rs = $conn->query($sql); // 쿼리 결과 변수는 객체로 생성됨
    //$total_count = mysqli_affected_rows($conn);
    $total_count = $conn->affected_rows;
    echo "total_count: ".$total_count."<br>";
    echo "result:".$rs;
    
    mysqli_close($conn);
?>