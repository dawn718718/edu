<?php

$conn = mysql_connect("localhost","root","1111"); //DB연결링크
mysql_set_charset("utf8",$conn);


 mysql_select_db("zdb");


 $query = "SELECT COUNT(*) FROM users WHERE userid='$_POST[userid]' AND userpw='$_POST[userpw]'";
 $result = mysql_query($query,$conn);
 $row = mysql_fetch_array($result);

 if($row[0]==1){
     echo "hi $_POST[userid] 님";
 } else {
     echo "사용자 인증이 필요하다";
     exit;
 }
 

?>
