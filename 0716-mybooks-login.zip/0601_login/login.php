<?php
//  echo $_POST['userid']."<br>";
//  echo $_POST['userpw']."<br>";

//1인 사용자
//  if($_POST['userid']=="asdf" && $_POST['userpw']=='1111') {
//     echo "안녕하세요.$_POST[userid]님.";
//  } else {
//      echo "이 페이지는 사용자 인증 필요";
//      exit;
//  }

 //다중사용자 처리
 $user = array("asdf"=>"1111","bbbb"=>"2222","cccc"=>"3333");
 if($_POST['userid'] && $_POST['userpw']==$user[$_POST['userid']]){
    echo "hi";
 }else {
     echo "no";
 }
?>