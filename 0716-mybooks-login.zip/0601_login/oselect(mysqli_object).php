<? 
    //DBMS에 접속 연결
    //mysqli의 확장버전. 객체로 $conn을 생성하여 각 메쏘드를 사용하는 방법
    $conn = new mysqli("localhost","root","1111","testdb"); //3306 디폴트 포트 사용
    if($conn->connect_error){ //객체의 메쏘드 사용시 . 대신 -> 사용함 (자바스와 다름)
        die("연결실패:".$conn->connect_error);
    }
    mysqli_set_charset($conn,"utf8");
    $sql = "SELECT * FROM student";
    $rs = $conn->query($sql); // 쿼리를 던져주면 객체로 생성됨

    //mysqli_num_rows(rs): 결과 레코드수 반환
    $count = $rs->num_rows;
    echo $count."<br>";

    // while($row = $rs->fetch_row()){
    //     echo  $row[0].":".$row[1].":".$row[2].":".$row[3].":".$row[4]."<br>";
    // }

    while(list($studentId,$name,$grade,$deptNo,$major)=$rs->fetch_array()){ 
        echo $studentId."#".$name."#".$grade."#".$deptNo."#".$major."#"."<br>";
     }
?>