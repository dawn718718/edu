<?php
$conn = mysql_connect("localhost","root","1111");
mysql_set_charset("utf8",$conn);
mysql_select_db("zdb");
$query = "INSERT INTO users (userid,userpw,name) VALUES ('$_POST[id]','$_POST[pw]','$_POST[name]')";
$rs = mysql_query($query,$conn);
//$row = mysql_fetch_array($rs);
$total_count = mysql_affected_rows($conn);
//echo "반영 갯수: ".$total_count."<br>";
if ($rs==1){
    echo "성공적으로 회원이 되었따";
} else {
    echo "실패했다";
}


mysql_close($conn);
?>

