<?
  $conn = mysql_connect("localhost","root","1111"); //DB연결링크
  mysql_set_charset("utf8",$conn);
  mysql_select_db("testdb");
  $query = "select * from student";
  $result = mysql_query($query,$conn);
   //------------------------------------------------------------
   // 결과셋의 갯수확인
   //mysql_num_rows(결과셋)
   $count = mysql_num_rows($result);
   echo "count : $count.<br>";
   
    //가독성 나쁨
    
    //while ($row = mysql_fetch_array($result)){
    //echo $row[0].":".$row[1].":".$row[2].":".$row[3].":".$row[4]."<br>"; 
    //}

    
    //가독성 좋음
    while(list($studentId,$name,$grade,$deptNo,$major)=mysql_fetch_array($result)){ 
       echo $studentId."#".$name."#".$grade."#".$deptNo."#".$major."#"."<br>";
    }
?>