<?
    $conn = mysql_connect("localhost", "root", "1111");
    mysql_query("set names utf8");
    mysql_select_db("zdb");

    $name = $_POST['name'];
    $userid= $_POST['userid'];
    $userpw= $_POST['userpw'];

    $query = "SELECT COUNT(*) FROM users WHERE userid='$userid'";
    $result = mysql_query($query, $conn);
    $row = mysql_fetch_array($result);

    if($row[0]==1){
    ?>
        <script>
            alert("이미 존재하는 아이디 입니다.");
            location.href="signup.html";
        </script>
    <?
        exit;
    }

    $sql = "INSERT INTO users(userid, userpw, name)
                   VALUES ('$userid', '$userpw', '$name')";
    $rs = mysql_query($sql, $conn);

    if($rs){
        echo "가입성공";
    ?>
        <script>
            alert("가입성공");
            location.href="login.html";
        </script>
    <?
    }else{
        echo "가입실패";
        exit;
    }



?>