<?php
    session_start();
    $SESSION['userid'] = "dawn718";
    $SESSION['item1'] = "sdfsdfsdf" //상품번호
    echo $_SESSION['message'];
    echo "<p>";
    echo "PHPSEID=",session_id();
?>