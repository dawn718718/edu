<?php
    session_start();
    $_SESSION['name'] = "홍길동";
    $_SESSION['age'] = 29;

    echo "<pre>";
        print_r($_SESSION);
    echo "</pre>";

    unset($_SESSION['age']);
    print_r($_SESSION);
    echo "</pre>";

?>