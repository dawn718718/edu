<?
   echo $_COOKIE['php'];
?>