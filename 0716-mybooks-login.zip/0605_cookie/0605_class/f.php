<?
    session_start();
    $_SESSION['message'] = "Welcome to PHP World!";
?>
<a href="g.php">이동</a>