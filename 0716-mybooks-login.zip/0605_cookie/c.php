<?php
    $result = setcookie("php","Cool",time()+60,"/"); //모든 경로를 포함한다
    if($result){
        echo "쿠키생성완료";
    }else {
        echo "쿠키생성실패";
    }

?>