<?php
/*
    header("Content-Type:application/json");
    $conn = new mysqli("localhost", "root", "1111", "zdb");
    
    if($conn->connect_errno)
        die('Connect error:'.$conn->connect_error);    
    mysqli_set_charset($conn, 'utf8');
    
    $userid = $_POST['userid'];
    $result = $conn->query("select count(*) as count from users where userid='$userid'");
    $row = $result->fetch_array();
    echo json_encode($row);
*/
    
    $conn = mysql_connect("localhost","root","1111");
    mysql_select_db("zdb");
    $userid = $_POST['userid'];
    $query="SELECT count(*) as count from users where userid='$userid'";
    $rs = mysql_query($query,$conn);
    
    $output = mysql_fetch_array($rs);
    echo json_encode($output); //제이슨 형태로 바꿔서 보내줌









?>