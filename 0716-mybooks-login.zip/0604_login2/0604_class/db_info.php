<?
    $conn = mysql_connect("localhost", "root", "hslim");
    mysql_query("set names utf8");
    mysql_select_db("zdb");
?>