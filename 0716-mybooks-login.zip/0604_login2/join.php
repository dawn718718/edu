<?php
    $conn = mysql_connect("localhost","root","1111");
    mysql_select_db("zdb");
    mysql_query("set names utf8");
    $userid = $_POST['userid'];
    $userpw = $_POST['userpw'];
    $name = $_POST['name'];


    //Insert
    $query="INSERT INTO users(userid, userpw, name) VALUES('$userid','$userpw','$name')";
    $rs=mysql_query($query,$conn);
    if($rs){
        ?>
        <script>
            alert ("성공적으로 가입되었다. 축하한다");
            location.href="logIn.html";
        </script>
        <?
    } else {
        ?>
        <script>
            alert ("가입에 실패했다. 다시 한번 시도해봐라");
            location.href="join.html";
        </script>
        <?
    }


    

?>