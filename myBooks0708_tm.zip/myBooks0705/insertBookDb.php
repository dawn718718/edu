<?php
include "conn.php";
$isbn=$_POST['isbn'];
$email=$_POST['email'];
$cover_path=$_POST['cover_path'];
$title=$_POST['title'];
$writer=$_POST['writer'];
$publisher=$_POST['publisher'];
$pub_date=$_POST['pub_date'];
$read_date=$_POST['read_date'];
$audio_path=$_POST['audio_path'];
$rem_words=$_POST['rem_words'];
$comments=$_POST['comments'];
$moreinfo=$_POST['moreinfo'];


$query="INSERT into books(isbn,email,cover_path,title,writer,publisher,pub_date,
read_date,audio_path,rem_words,comments,moreinfo,book_reg_date) 
values('$isbn','$email','$cover_path','$title','$writer','$publisher',
'DATE_FORMAT($pub_date,%Y-%m-%d)','$read_date','$audio_path','$rem_words','$comments','$moreinfo', curdate())";

$rs=mysql_query($query,$conn);
if($rs){
?>
<script>
    alert("성공이다. 책장으로 이동한다.");
    location.href="showBookShelf.php";
</script>
<?php
} else {

?>
<script>
    alert("실패다....");
    location.href="addBook.php";
</script>
<?php
}

?>