<?php
include "conn.php";
$email=$_POST['email'];
$pwd=$_POST['pwd'];
//입력한 이멜과 패워가 동시에 들어있는 레코드가 1개 있으면, 로그인 성공.
//없으면, 로그인 실패
$query = "SELECT count(*) from users where email='$email' and pwd='$pwd'";
$rs=mysql_query($query,$conn);
$row=mysql_fetch_array($rs);
if($row[0]==1) {
    ?>
        <script>
            alert("로그인에 성공하였습니다. 홈으로 이동합니다.");
            location.href="index.php";
        </script>

    <?php
} else {
    ?>
<script>
    alert("로그인에 실패하였습니다. 다시 시도해보세요. ");
    
</script>
    <?php
}
mysql_close($conn)
?>