<?php
    include "db_info.php";
    //게시물을 잘라서 가져온다. 0, 10, 20, 30...
    $no = $_GET['no']; // 게시물 시작 인덱스 번호
    $page_size = 10; //한 페이지 내 게시물 갯수
    $page_list_size = 10; // 한 리스트 내 페이지 갯수

    $PHP_SELF = $_SERVER['PHP_SELF']; //자기 자신의 URL 경로

    $query = "SELECT * from board limit $no,$page_size";

    $result = mysql_query($query,$conn);

    $query = "SELECT count(*) from board";
    $count = mysql_query($query,$conn);
    $rs = mysql_fetch_row($count);
    $total_row = $rs[0]; // 게시물의 총 갯수와 총 페이지수 계산
    echo $total_row;

    //음수일때 예외 처리
    if($total_row <=0) {
        $total_row = 0;
    }
    //total page는 0부터 시작. 페이지갯수 10/10 = 1 :  2페이지를 의미
    $total_page = floor(($total_row -1) / $page_size);
    $current_page = floor($no / $page_size);
?>

<table border=1>
    <tr>
        <td>번호</td>
        <td>제목</td>
        <td>글쓴이</td>
        <td>날짜</td>
        <td>조회수</td>
    </tr>
<?php
    while(list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view)=mysql_fetch_array($result)){
?>
    <tr>
        <td align=center><a href="read.php?id=<?=$id?>"><?=$id?></td>
        <td><?=$title?></td>
        <td><?=$name?></td>
        <td><?=$wdate?></td>
        <td><?=$view?></td>
    </tr>
<?php
}
?>
<tr align = "center">
    <td colspan=5>
        <?php
            //페이지 리스트 첫번째 페이지 구하기
            //0, 10, 20, 30, 40 ... 1/10 = int(0.1) = 0의미
            $start_page= (int)($current_page / $page_list_size) * $page_list_size;
            
            //페이지리스트 마지막 페이지 구하기
            //0부터 시작함 첫번째 페이지 + 9페이지 = 마지막페이지
            $end_page = $start_page + $page_list_size -1;

            ##페이징
             for ($i= $start_page; $i <= $end_page; $i++) {
                 $page = $i * $page_size; //전달될 페이지 값을 no로 변환
                 $page_num = $i+1; //보여질 페이지 번호
                 echo "<a href=\"$PHP_SELF?no=$page\">";
                 echo "$page_num ";
                 echo "</a>";
             }

        ?>
        <!--1 2 3 4 5 6 7 8 9 10-->
    </td>
</tr>
</table>
<br>
<a href="write.php">글쓰기</a>

