<?php
 $conn = mysql_connect("localhost","root","1111");
 mysql_select_db("zdb");
 mysql_query("set names utf8");

?>