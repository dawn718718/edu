<?php
    include "../common/db_info.php";
    $userid = $_GET['userid'];
    //echo $userid;
    $query = "SELECT userid,userpw,name from users where userid='$userid'";
    $result=mysql_query($query,$conn);
    list($userid,$userpw,$name)=mysql_fetch_array($result);
    ?>
    <form name="myForm" action="update_proc.php" method="post">
        <input type="text" name="userid" value="<?=$userid ?>" readonly > <br>
        <input type="text" name="userpw" value="<?=$userpw ?>"><br>
        <input type="text" name="name" value="<?=$name ?>"><br>
        <input type="submit" value="수정">

    </form>
  