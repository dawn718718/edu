<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>관리자 화면</title>
</head>
<body>
    
    <?php
    include "../common/db_info.php";
    $query = "SELECT userid, userpw, name from users";
    $result = mysql_query($query,$conn);
    //list 함수: 배열을 변수로 받은 것 뿐
    ?>
    
        <table border=1>
        <caption>회원목록<caption>
        <tr><td>userid</td><td>password</td><td>name</td><td>수정</td><td>삭제</td></tr>
    <?
        while(list($userid, $userpw, $name)=mysql_fetch_array($result)){ //fetch_array는 값이 없으면 그냥 false리턴하고 끝남
    ?>      
        <tr>
            <td><?= $userid?></td>
            <td><?= $userpw?></td>
            <td><?= $name?></td>
            <td><a href="adminupdate.php?userid=<?= $userid?>">수정</td>
            <td><a href="admindelete.php?userid=<?= $userid?>">삭제</td>
        </tr>  
    <?
    }
    ?>
    </table>

    <?
    /*
    while ($row=mysql_fetch_array($result)) {
        $row[$i]=mysql_fetch_array($result);
        echo $row[0].$row[1].$row[2];
    }
    // echo $row[0].$row[1].$row[2];
    // echo $row1[0].$row1[1].$row1[2];
    // echo $row2[0].$row2[1].$row2[2];
    
    
    //echo $row[0].$row[1].$row[2];
    */
        ?>
      
</body>
</html>