<?php
    include "../common/db_info.php"; //상위폴더로 올라가서
    $aid = $_POST['adminid']; //html에서 post로 입력받은 값
    $apw = $_POST['adminpw']; //html에서 post로 입력받은 값
    $query = "SELECT admin_id,adminn_m from admin where admin_id='$aid' and admin_pw='$apw' ";
    $result=mysql_query($query,$conn);
    list($adminid,$adminnm)=mysql_fetch_array($result);
    //echo $admin_id.":".$adminn_m;
    if (!empty($adminid)){//관리자 로그인 성공시, 세션변수에 그 아이디를 넣어줌
        session_start();
        $_SESSION['idid'] = $adminid;//세션 변수 "$_SESSION['admin_id']"에 db의 관리자값을 넣음
        $_SESSION['aaa'] = $adminnm;//C:\xampp\tmp 에 세션변수의 내용이 파일로 만들어짐       
?>
        <script>
            location.href="adminlist.php"; // 관리자 로그인 성공시 이동할 페이지(회원 목록) 지정
        </script>

<?
    } else{ //관리자 로그인 실패
?>
        <script>
            alert ("아이디와 패스워드 확인해라");
            history.back(-1);
           //location.href="admin.html"
        </script>


    

<?   
    }
    mysql_close($conn);
?>