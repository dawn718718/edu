<?php
    include "../common/db_info.php";
    $userid = $_GET['userid'];
    //echo $userid;
    $query = "DELETE from users where userid='$userid'";
    $result=mysql_query($query,$conn);
    if ($result) {
    ?>
        <script>
        alert ("성공 삭제");
        location.href="adminlist.php"
        </script>
    <?php
    }else {
    ?>
     <script>
        alert ("성공 실패");
        location.href="adminlist.php"
        </script>
    <?php
    }
    ?>
    
  