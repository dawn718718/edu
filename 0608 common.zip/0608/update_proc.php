<?php
// 전달받은 정보를 디비에 업뎃하기
include "../common/db_info.php";

$userid = $_POST['userid'];
$userpw = $_POST['userpw'];
$name = $_POST['name'];
$query = "UPDATE users
            set userpw = '$userpw', name='$name'
            where userid = '$userid'";
$result = mysql_query($query,$conn);
if($result){
?>
<script>
    alert("성공");
    location.href="adminlist.php";
</script>
<?


}else {
?>
<script>
    alert("실패");
    location.href="adminlist.php";
</script>
<?
}
?>