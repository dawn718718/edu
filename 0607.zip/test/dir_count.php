<?php

/*
디렉토리 함수
chdir: 현재 디렉토리를 변경
getcwd: 현재 작업 디렉토리
opendir: 디렉토리 핸들 전달
readir: 디렉토리 핸들로 엔트리 읽기
scandir: 디렉토리 파일을 배열로 전달
closedir: 디렉토리 핸들 닫기
is_dir: 디렉토리인지 확인, 디렉토리면 true / false

*/
//test 폴더 아래 있는 test1이 디렉토리인지 확인
$dir = "test1";
echo is_dir($dir)?"directory" : "no directory";
echo "<br>";
//현재 경로 확인
echo getcwd();
echo "<br>";
//test1 디렉토리를 열어서, 읽어서, 그 안에 파일명들을 출력하라
$dh = opendir("test1");
while(($file = readdir($dh)) !== false) { //파일이 뭔가 들어있을때까지만 계속 실행해라
    echo "filename: ".$file."<br>";
}
closedir($dh);

?>