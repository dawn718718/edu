<?php

$conn = mysql_connect("localhost","root","1111");
mysql_select_db("zdb",$conn);
// $query1 = "SELECT number FROM counter where seq=1"; //int로 선언한 경우 콤마 없이 값 입력
// $rs = mysql_query($query1,$conn);
// $output = mysql_fetch_row($rs); // 0번째에 첫번째 값이 '0'이 들어간 배열을 가져옴
// $val = $output[0];
//$query2 = "UPDATE counter SET number='$val++', dt= WHERE seq=1";
$query1 = "UPDATE counter SET number=number+1, dt=now() WHERE seq=1";
mysql_query($query1,$conn);
$query2 = "SELECT * FROM counter where seq=1"; //int로 선언한 경우 콤마 없이 값 입력
$rs = mysql_query($query2,$conn);
list($seq, $num, $dt) = mysql_fetch_array($result);
$output = mysql_fetch_row($rs);

echo $output[0].":".$output[1].":".$output[2];
//echo $rs2;



?>