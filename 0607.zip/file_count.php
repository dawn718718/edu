<?php

/*
파일 함수
file : 파일의 내용을 배열로 가져온다 (행단위)
fopen: 파일 열기. 실패하면 false // 옵션: w, r
fclose: 파일 닫기. 성공하면 true 실패하면 flase
fgets: 열린 파일에서 한줄을 반환
is_file: 파일인지 확인 파일: true / false
fwrite: 파일을 쓰기

디렉토리 함수
chdir: 현재 디렉토리를 변경
getcwd: 현재 작업 디렉토리
opendir: 디렉토리 핸들 전달
readir: 디렉토리 핸들로 엔트리 읽기
scandir: 디렉토리 파일을 배열로 전달
closedir: 디렉토리 핸들 닫기
is_dir: 디렉토리인지 확인, 디렉토리면 true / false

*/

/*
$file = file("test.txt");
echo $file[2];

$file = "count.txt";
echo is_file($file)? "file" : "no file";
echo "<br>";

$count = file("count.txt");
echo trim($count[0]);


$file = fopen("count.txt","r");
$count = fgets($file); // "count.txt"를 열어 첫번째 줄을 읽어와 $count에 넣음
echo $count;
*/
$count = file("count.txt");
$count = $count[0];
$count++; // 0->1
$fp = fopen("count.txt","w");
fwrite($fp,$count++);
fclose($fp);

echo $count;

?>