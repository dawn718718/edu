<?php
    include "db_info.php";
    $query = "SELECT * from board";
    $result = mysql_query($query,$conn);
    
?>

<table border=1>
    <tr>
        <td>번호</td>
        <td>제목</td>
        <td>글쓴이</td>
        <td>날짜</td>
        <td>조회수</td>
    </tr>
<?php
    while(list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view)=mysql_fetch_array($result)){
?>
    <tr>
        <td align=center><a href="read.php?id=<?=$id?>"><?=$id?></td>
        <td><?=$title?></td>
        <td><?=$name?></td>
        <td><?=$wdate?></td>
        <td><?=$view?></td>
    </tr>
<?php
}
?>
</table>
<br>
<a href="write.php">글쓰기</a>

