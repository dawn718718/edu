-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: mybooks
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `isbn` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cover_path` varchar(100) DEFAULT NULL,
  `title` varchar(30) NOT NULL,
  `writer` varchar(20) NOT NULL,
  `publisher` varchar(20) DEFAULT NULL,
  `pub_date` date DEFAULT NULL,
  `read_date` date DEFAULT NULL,
  `audio_path` varchar(100) DEFAULT NULL,
  `rem_words` text,
  `comments` text,
  `moreinfo` varchar(50) DEFAULT NULL,
  `book_reg_date` date DEFAULT NULL,
  PRIMARY KEY (`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES ('$isbn','$email','https://bookthumb-phinf.pstatic.net/cover/133/659/13365938.jpg?type=m1&udate=20180313','$title','$writer','$publisher','0000-00-00','0000-00-00','$audio_path','$rem_words','$comments',NULL,'2018-07-08'),('$iskbn','$email','https://bookthumb-phinf.pstatic.net/cover/135/614/13561489.jpg?type=m1&udate=20180630','$title','$writer','$publisher','0000-00-00','0000-00-00','$audio_path','$rem_words','$comments','$moreinfo','2018-07-08'),('0501','b@b.com','https://bookthumb-phinf.pstatic.net/cover/133/302/13330217.jpg?type=m1&udate=20180331','so cool','kim jen','jeny pub','0000-00-00','2018-05-02','audio/180703_news_re','sentence to rem 0502','commet 0502',NULL,'2018-07-08'),('0702','b@b.com','https://bookthumb-phinf.pstatic.net/cover/133/659/13365938.jpg?type=m1&udate=20180313','Love you','Sam','Publisher','0000-00-00','2018-07-02','audio/180703_news_re','sentence to rem 0702','commet 0702',NULL,'2018-07-08'),('07021','b@b.com','https://bookthumb-phinf.pstatic.net/cover/135/614/13561489.jpg?type=m1&udate=20180630','no way!','asas','fgfg','0000-00-00','2018-06-02','audio/180703_news_re','sentence to rem 0602','commet 0602',NULL,'2018-07-08'),('1162205806','a@a.com','https://bookthumb-phinf.pstatic.net/cover/133/302/13330217.jpg?type=m1&udate=20180331','? ??? ?? ???? ?? ?? ??','???','?????','0000-00-00','2018-07-01','audio/180703_news_re','afaf','2323',NULL,'2018-07-08'),('456456','b@b.com','https://bookthumb-phinf.pstatic.net/cover/133/302/13330217.jpg?type=m1&udate=20180331','Love you','Sam','Publisher','0000-00-00','2018-07-13','audio/180703_news_re','f','f',NULL,'2018-07-08'),('456456fffhh','b@b.com','https://bookthumb-phinf.pstatic.net/cover/133/302/13330217.jpg?type=m1&udate=20180331','Love you','Sam','Publisher','0000-00-00','2018-07-13','audio/180703_news_re','m','m',NULL,'2018-07-08'),('456456fffhhq','b@b.com','https://bookthumb-phinf.pstatic.net/cover/133/302/13330217.jpg?type=m1&udate=20180331','Love you','Sam','Publisher','0000-00-00','2018-07-13','audio/180703_news_re','q','m',NULL,'2018-07-08'),('456456fffhhqcc','b@b.com','https://bookthumb-phinf.pstatic.net/cover/123/324/12332478.jpg?type=m1&udate=20171228.jpg?type=m1&ud','Love you','Sam','Publisher','0000-00-00','2018-07-13','audio/180703_news_re','cc','cc',NULL,'2018-07-08'),('456456fffhhqccdd','b@b.com','https://bookthumb-phinf.pstatic.net/cover/133/302/13330217.jpg?type=m1&udate=20180331','Love you','Sam','Publisher','0000-00-00','2018-07-13','audio/180703_news_re','dd','dd',NULL,'2018-07-08'),('8960975370','b@b.com','images/smoke.jpg','Love you','Sam','Publisher','0000-00-00','0000-00-00','audio/180703_news_re','sentence to remember 1','my comment 1',NULL,'2018-07-08'),('8960975370 9788960975378','a@a.com','https://bookthumb-ph','we love you','Sam Pokai','Publisher Company','0000-00-00','0000-00-00','','','','http://....','2018-07-08'),('8960975370 9788960975378sdfsdfsfsdfsdfsdfsdf','a@a.com','https://bookthumb-ph','we love you','Sam Pokai','Publisher Company','0000-00-00','0000-00-00','','','','http://....','2018-07-08'),('8960975370 9788960975378zxczxc','a@a.com','https://bookthumb-phinf.pstatic.net/cover/133/302/13330217.jpg?type=m1&udate=20180331','we love you','Sam Pokai','Publisher Company','0000-00-00','0000-00-00','','dsf','sdfsdf','http://....','2018-07-08'),('8960975370 978896097537??8','a@a.com','https://bookthumb-ph','we love you','Sam Pokai','Publisher Company','0000-00-00','0000-00-00','','','','http://....','2018-07-08'),('8960975370-1','b@b.com','images/smoke.jpg','Love you','Sam','Publisher','0000-00-00','0000-00-00','audio/180703_news_re','','',NULL,'2018-07-08'),('8960975370-2','b@b.com','images/smoke.jpg','Love you','Sam','Publisher','0000-00-00','0000-00-00','audio/180703_news_re','','',NULL,'2018-07-08');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-08 23:23:02
