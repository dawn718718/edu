<?
include "conn.php";
?>

<!DOCTYPE html>

<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Elate &mdash; 100% Free Fully Responsive HTML5 Template by FREEHTML5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
		<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
		<meta name="author" content="FREEHTML5.CO" />

		<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
		<link rel="shortcut icon" href="favicon.ico">
		<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Simple Line Icons -->
		<link rel="stylesheet" href="css/simple-line-icons.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Bootstrap  -->
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/style.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		<link href="https://fonts.googleapis.com/css?family=Yeon+Sung" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
		<style>
		.sizeBookCol {
			width:115px;
			height:156px;
			margin: 25px; 
			float:left;
			
		}
		.moreBookButton {
			font-size:15px;
			background-color:#7a7a7a;
			color: black;
			text-decoration:none;
		}
		a {
			text-decoration:none;
		}
		.loginComment {
			text-align:right;
			color:black;
			font-size:17px;
		}
		.howtouse_title {
			color:#595959;font-size:45px;text-align:center;margin-top:200px;
		}
		.stepNum {
			font-size:100px;text-align:center;font-weight:bold;margin-right:30px;
		}
		.stepExp{
			font-size:26px; display:inline;vertical-align:middle;text-align:left;
		}
		 /* * {
			 border: 1px solid red;
		 } */
		
		</style>
	</head>

	<body>
		<header role="banner" id="fh5co-header">
			<div class="container">
				<?include("header.php");?>
				<!-- 로그인 세션키 가져오기 -->
				<?php
					session_start();
					// if(!isset($_SESSION['email']) || !isset($_SESSION['username'])) {
					// 	echo "<meta http-equiv='refresh' content='0;url=signin.php'>";
					// 	exit;
					// }
					$email = (isset($_SESSION['email']))?  $_SESSION['email']: "";
					$username = (isset($_SESSION['username']))? $_SESSION['username'] : "";
				?>

<? if(!$email == ""){?>
				<div class="row">
							<div class="col-md-12 loginComment" >안녕하세요. <?=$username.'('.$email.')'?>님 &nbsp
							  <!-- <a href='signout.php' style="text-decoration:none; color:white">로그아웃</a> -->
							  <button class="btn btn-sm" onclick=logout()>Logout</button>
							</div>
				</div>	
				<script>
					function logout() {
						var a = confirm("로그아웃하시겠습니까?");
						if(a){
							location.href="signout.php";
							}
						else{
							return;
							}
					}
				</script>
<?}?>
			</div>
		</header>
		<!-- 상단 탑 메인 이미지 및 글씨 -->
		<section id="fh5co-home" data-section="home" style="background-image: url(images/full_image_2.jpg);" data-stellar-background-ratio="0.5">
			<div class="gradient"></div>
			<div class="container">
				<div class="text-wrap">
					<div class="text-inner">
						<div class="row">
							<div class="col-md-8 col-md-offset-2">
								<h1 class="to-animate">나만의 책장을 만들어보세요.</h1>
								<h2 class="to-animate">읽었던 책이 잘 기억나지 않나요? 내가 좋아했던 문장, 남기고 싶은 말을 책 정보와 함께 노트로 기록해보세요.</h2><br>
								
							</div>
						</div>

<? if($email == ""){?>		
						<!-- 세션키 없을 경우 / 로그인 입력창 및 임시키-->
						<div class="row">
							<div class="col-md-8 col-md-offset-2">
								<div class="to-animate" style="color:#1f1f14;font-size: 20px;">모든 메뉴는 <strong>로그인 후</strong> 이용할 수있습니다.</div><br><br>
							</div>
						</div>

						<div class="row" style="height:100px;">
							<button type="button" class="btn btn-primary btn-lg" style="margin-left:30px;margin-right:5px" onclick="GoSignin()">로그인</button>
							<button type="button" class="btn btn-primary btn-lg" onclick="GoJoin()">회원가입</button>
						</div>
						<script>
						function GoSignin(){
							location.href="signin.php";
						}
						function GoJoin(){
							location.href="signup.php";
						}
						</script>
						
						
						
						
<?} ?>
					</div>
				</div>
			</div>
			<div class="slant"></div>
		</section>

	<!-- 3줄 버튼 (새 책 추가, 내 책장가기, 검색하기) -->
		<section id="fh5co-intro">
			<div class="container">
				<div class="row row-bottom-padded-lg">
					<div class="fh5co-block to-animate" style="background-image: url(images/img_7.jpg);">
						<div class="overlay-darker"></div>
						<div class="overlay" style="border-color: grey"></div>
						<div class="fh5co-text">
							<i class="fh5co-intro-icon icon-bulb"></i>
							<h1>새 책 추가하기</h1>
							<p style="font-size:18px;">네이버 책 데이터베이스를 이용한 책 검색을 통해 원하는 책을 손쉽게 내 책장으로 가져와 관리할 수 있습니다.</p>
<? if(!$email == ""){?>		
							<p><a href="searchBook.php" class="btn btn-primary">Click Me</a></p>
<?}?>

<? if($email == ""){?>
							<p onclick="alert()"><a class="btn btn-primary">Click Me</a></p>
							<script>
							function alert(){
								var a = confirm("로그인한 경우만 사용 가능한 메뉴입니다. 로그인 하시겠습니까?");
								if(a){
									location.href="signin.php";
								}else {
									return;
								}
							}
							</script>

<?}?>
						</div>
					</div>

					<div class="fh5co-block to-animate" style="background-image: url(images/img_8.jpg);">
						<div class="overlay-darker"></div>
						<div class="overlay"  style="border-color: grey"></div>
						<div class="fh5co-text">
							<i class="fh5co-intro-icon icon-wrench"></i>
							<h1>책장 보기</h1>
							<p style="font-size:18px;">내 책장에 있는 책들을 갤러리 형식으로 보여주어, 내가 읽은 책에 대한 정보 및 나의 개인적인 기록들을 둘러보고 수정할 수 있습니다. </p>
							<p><a href="showBookShelf.php" class="btn btn-primary">Click Me</a></p>
						</div>
					</div>
					<div class="fh5co-block to-animate" style="background-image: url(images/img_10.jpg);">
						<div class="overlay-darker"></div>
						<div class="overlay" style="border-color: grey"></div>
						<div class="fh5co-text">
							<i class="fh5co-intro-icon icon-rocket"></i>
							<h1>책 찾기</h1>
							<p style="font-size:18px;">내 책장에서 추가했던 책을 검색할 수 있습니다. 책의 제목, 저자, 읽은 날짜를 필터링해 검색 가능합니다.</p>
							<p><a href="#" class="btn btn-primary">Click Me</a></p>
						</div>
					</div>
				</div>
			</div>
		</section>


<? if($email == ""){?>		
<!-- 세션키 없을 경우 / 갤러리 캡쳐 이미지-->
	<div class="container">
		<div class="row row-bottom-padded-sm" id="SearchR">
			<img class="col-sm-6" src="images/bookshelf_withTitle.png" alt="책장샘플이미지" height="600px">
			<div class="col-sm-6" >
				<p style="font-size:50px;color:#595959; margin-top:180px; margin-left:70px;">책을 추가하고<br><span style="font-weight:bold">나만의 책장</span>을<br>만들어 보세요.</p>
			</div>
		</div> 
	</div>
<!-- 세션키 없을 경우 / 책 추가 방법 3 스텝-->
	</div class="container">
		<div class="row row-bottom-padded-sm">
			<p class="howtouse_title">내가 읽은 책을 <br><span style="font-weight:bold;">검색창</span>을 이용해서 책장에 넣는 방법</p>
		</div>

		<!-- step1 -->
		<div class="row row-bottom-padded-sm" style="text-align:center;" id="SearchR">
			<div class="col-sm-3" style="margin-left:200px;">
				<img src="images/search_img.png" alt="step1" width="200">
			</div>
			<div class="stepNum col-sm-1">1</div>
			<div class="stepExp col-sm-4"><span style="font-weight:bold">책 제목을 검색한다.</span> <br>네이버 책 DB와의 연동으로, 사용자가 직접 책 정보를 입력하지 않고 책 제목이나 저자 검색어만으로 책을 쉽게 추가할 수 있어요.</div>
		</div>

		<!-- step2 -->
		<div class="row row-bottom-padded-sm" style="text-align:center;" id="SearchR">
			<div class="col-sm-3" style="margin-left:200px;">
				<img src="images/step2-1.png" alt="step2" width="200">
			</div>
			<div class="stepNum col-sm-1">2</div>
			<div class="stepExp col-sm-4"><span style="font-weight:bold">추가할 책을 선택한다.</span> <br>자동으로 입력된 책의 기본적인 정보 외에 나만의 서평이나 기억하고 싶은 문장을 담은 독서 노트를 추가할 수 있어요.</div>
		</div>

		<!-- step3 -->
		<div class="row row-bottom-padded-sm" style="text-align:center;" id="SearchR">
			<div class="col-sm-3" style="margin-left:200px;">
				<img src="images/step3.png" alt="step3" width="200">
			</div>
			<div class="stepNum col-sm-1">3</div>
			<div class="stepExp col-sm-4"><span style="font-weight:bold">책장에 넣는다.</span><br>내가 읽은 책들을 한눈에 책장에서 보듯이 확인할 수 있으며, 책 표지를 클릭하면 책 정보 및 책에 대한 내 기록을 언제든지 다시 열어 볼 수 있어요.</div>
		</div>
	</div>
<?}?>


<!-- 세션키 있을 경우 / 책 갤러리 -->
<? if(!$email == ""){?>

		<section id="fh5co-work" data-section="work">
			<div class="container">
				<div class="row">
					<div class="col-md-12 section-heading text-center">
						<h2 class="to-animate">나의 책장</h2>
						<div class="row">
							<div class="col-md-8 col-md-offset-2 subtext to-animate">
							<?php
								$query="SELECT count(isbn) from books where email='$email'";
								$rs=mysql_query($query,$conn);
								$row=mysql_fetch_array($rs);
								if($row[0]==0){
									?>
									<script>
									//질문
									$(document).ready(
										$("#gallery_title_blank").text("아직 책장에 책이 없습니다. 책을 추가해보세요");
										$("#show_more_books_btn").hide();
										$("#add_book_btn").show();
									);
									</script>
								<?}?>
								<h3 id="gallery_title">가장 최근에 추가한 책을 순서대로 보여줍니다.</h3><br>
								<h2 id="gallery_title_blank" style="color:black"></h2>
							</div>
						</div>
					</div>
				</div>
				<div id="row_for_blank" class="row">
					
				</div>
					<!-- 루프 돌릴 갤러리 column 단위 시작-->
					<div class="row row-bottom-padded-sm" id="SearchR">
							<?php
								
								// 책이 하나도 책장에 없을 경우
								$query="SELECT count('isbn') from books where email='$email'";
								$rs=mysql_query($query,$conn);
								$row=mysql_fetch_array($rs);
								if($row[0]==0){
									?>
									<script>
									//질문
									$(document).ready(
										$("#row_for_blank").html("<div id='blank_cover' class='col' style='width:100px;height:170px;border:1px dashed black;margin-left:300px';>")
									);
									</script>
								<?}
								//그 외 경우
								$query="SELECT * from books where email='$email' order by book_reg_date desc limit 35";
								$rs=mysql_query($query,$conn);
								$i=0;
								while(list($isbn,$email_db,$cover_path,$title,$writer,$publisher,$pub_date,
								$read_date,$audio_path,$rem_words,$comments,$moreinfo,$book_reg_date)=mysql_fetch_array($rs)){;
		
							?>
								<div class="sizeBookCol">
									<a href="OpenBookDetails.php?isbn=<?=$isbn?>">
										<div>
											<img src='<?=$cover_path?>' alt='<?=$title?>' width="115" height="156" >
										</div>
									</a>
								</div> 
							<?php
								}
							?>

					</div> 
					<!-- 갤러리 column 단위 끝-->
					<div id="show_more_books_btn" class="row">
						<a href="showBookShelf.php"><button type="button" class="btn btn-primary col-md-4 " style="margin-left:20px;font-size:17px;" ><stron>책 더보기</strong></button></a>
					</div>
					<div id="add_book_btn" class="row">
					</div>
			
			</div>
		</section>
<?} ?>


	
		<!-- 통계 -->
		<section id="fh5co-counters" style="background-image: url(images/full_image_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="fh5co-overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-12 section-heading text-center to-animate">
						<h2>내 책에 관한 기록</h2>
					</div>
				</div>
				<?
				$query1="SELECT count(*) from books where email='$email'";
				$rs1=mysql_query($query1,$conn);
				$row1=mysql_fetch_array($rs1);
				
				//질문
				?>
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-briefcase to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="89" data-speed="5000" data-refresh-interval="50"><?=$row1[0]?></span>
							<span class="fh5co-counter-label">읽은 책 수</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-code to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="2343409" data-speed="5000" data-refresh-interval="50">2343409</span>
							<span class="fh5co-counter-label">오디오 북 수</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-cup to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="1302" data-speed="5000" data-refresh-interval="50">1302</span>
							<span class="fh5co-counter-label">나의 코멘트 수</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-people to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="52" data-speed="5000" data-refresh-interval="50">52</span>
							<span class="fh5co-counter-label">만난 작가 수</span>
						</div>
					</div>
				</div>
			</div>
		</section>

	
		<footer id="footer" role="contentinfo">
			<a href="#" class="gotop js-gotop"><i class="icon-arrow-up2"></i></a>
			<div class="container">
				<div class="">
					<div class="col-md-12 text-center">
						<p>&copy; MyBooks. All Rights Reserved. <br>Created by <a href="http://freehtml5.co/" target="_blank">김재연</a></p>
						
					</div>
				</div>
				
			</div>
		</footer>
		


	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Counter -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>


	<!-- For demo purposes only styleswitcher ( You may delete this anytime ) -->
	<script src="js/jquery.style.switcher.js"></script>
	<script>
		$(function(){
			$('#colour-variations ul').styleSwitcher({
				defaultThemeId: 'theme-switch',
				hasPreview: false,
				cookie: {
		          	expires: 30,
		          	isManagingLoad: true
		      	}
			});	
			$('.option-toggle').click(function() {
				$('#colour-variations').toggleClass('sleep');
			});
		});
	</script>
	
	<!-- Main JS (Do not remove) -->
	<script src="js/main.js"></script>

	</body>
</html>


