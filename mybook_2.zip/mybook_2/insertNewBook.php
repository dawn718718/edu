<?php
include "conn.php";
$title = $_GET['title'];
$writer= $_GET['writer'];
$publisher= $_GET['publisher'];
$pub_date= $_GET['pub_date'];
$pages= $_GET['pages'];
//$audio_path= $_GET['audio_path'];
$read_date= $_GET['read_date'];
$comments= $_GET['comments'];
$rem_words= $_GET['rem_words'];
//$cover_path= $_GET['cover_path'];

$sql = "INSERT into books (book_id,title,writer,publisher,pub_date,pages,read_date,comments,rem_words)
values (null, '$title','$writer','$publisher','$pub_date',$pages,'$read_date','$comments','$rem_words')";
$rs=mysql_query($sql,$conn);
if($rs) {
?>
    <script>
        alert ("오오오! 성공적 입력완료!");
        location.href="index_default.html";
    </script>
<?php
}else {
?>
    <script>
    alert("실패다. 다시 해보셈!");
    location.href="add_new.html";
</script>
<?php
}
?>