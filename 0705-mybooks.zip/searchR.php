<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>
        <p>검색 결과</p>
        <form action="" method="GET">
            <div id="cover"></div>
            제목: <input type="text" name="title" id="title">
            저자: <input type="text" name="writer" id="writer">
        </form>
    </div>
</body>
</html>