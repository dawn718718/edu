<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup core CSS file -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Jquery src -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<!-- Magnific javascript -->
	<script src="./jquery.magnific-popup.js"></script>
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<!-- Flaticons  -->
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->


</head>
<body>
    <div class="auto_input">
        <h2>검색하기</h3>
        <form method="POST" action="goApiNaver.php">
            <input class="search_box" placeholder="네이버 책 정보를 자동으로 가져옵니다" type="search" id="keyword" name="keyword">
            <input class="search_button" type="submit" id="submit" value="검색">
        </form>
    </div>

    <?php
    include "conn.php";
    $sql = "SELECT * from books";
    $rs = mysql_query($sql,$conn);
    ?>

    <div id="colorlib-rooms" class="colorlib-light-grey"><!-- 최상위 컨테이너-->
        <div class="container">
            <div class="row">
                
        <?php 
            $i=0;
            while(list($email,$isbn,$cover_path,$title,$writer,$publisher,$pub_date,$pages,$read_date,$audio_path,$rem_words,$comments,$book_reg_date)=mysql_fetch_array($rs)){        
        ?>
    
                <div class= "col-md-4 room-wrap animate-box">
                    <div class="popup-gallery">
                        <a href="roomDetail.php?isbn=<?=$isbn?>" title="<?=$title?>" ><img src="<?=$cover_path?>" width="300" height="300"></a>
                    </div>
                    <div class="desc text-center"> <!--룸 설명-->
                        <!-- <span class="rate-star"><i class="icon-star-full full"></i><i class="icon-star-full full"></i><i class="icon-star-full full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i></span> -->
                        <h3 style="font-family: Arial, Helvetica, sans-serif;"><a href="rooms-suites.html" >책제목: <?=$title?></a></h3>
                        <h3 style="font-family: Arial, Helvetica, sans-serif;"><a href="rooms-suites.html" >저자: <?=$writer?></a></h3>
                        <!-- <p class="price">
                            <span class="currency">$</span>
                            <span class="price-room"><?=number_format("$writer")?></span>
                            
                            <span class="per">원</span>
                            <span class="per">/ per night</span>
                        </p> -->
                        <!-- <ul>
                            <li><i class="icon-check"></i><?=$writer?></li>
                            <li><i class="icon-check"></i><?=$publisher?></li>
                            <li><i class="icon-check"></i><?=$pub_date?></li>
                        </ul> -->
                        <p><a href="bookdate.php?room_id=<?=$room_id?>" class="btn btn-primary">예약하기</a></p>
                    </div>
                </div>
                        
                        
    <?php
                        $i++;
                    }
    ?>
                        
                </div><!-- 룸들 최하단 컨테이너 끝-->
            </div><!-- 룸들 상위 (양쪽 여백 포함) 컨테이너 끝-->
        </div>
</body>
</html>