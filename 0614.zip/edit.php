<?php
    include "db_info.php";
    $id = $_GET['id'];
    $query = "SELECT * from my_board where id='$id'";
    $result = mysql_query($query,$conn);
    list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view) = mysql_fetch_array($result);

?>

<form action="update.php?id=<?=$id?>" method="post">
    <table border=1>
        <tr>
            <td colspan=2>글을 수정하세요</td>

        </tr>
        <tr>
            <td>이름</td>
            <td><input type="text" name="name" size="20" maxlength="10" value="<?=$name?>"></td>
        </tr>
        <tr>
            <td>이메일</td>
            <td><input type="text" name="email" size="20" maxlength="20" value="<?=$email?>"></td>
        </tr>
        <tr>
            <td>비번</td>
            <td><input type="text" name="pass" size="20" maxlength="20" value="<?=$pass?>"></td>
        </tr>
        <tr>
            <td>제목</td>
            <td><input type="text" name="title" size="65" maxlength="20" value="<?=$title?>"></td>
        </tr>
        <tr>
            <td>내용</td>
            <td><textarea name="content" cols="70" rows="20"><?=$content?></textarea></td>
        </tr>
        <tr>
            <td colspan=2>
               <input type="submit" value="저장"> &nbsp;
               <input type="reset" value="다시쓰기"> &nbsp;
               <input type="button" value="되돌아가기" onclick="history.back(-1)"> 
            </td>

        </tr>
    </table>
</form>