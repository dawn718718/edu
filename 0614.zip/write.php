
<form action="insert.php" method="post">
    <table border=1>
        <tr>
            <td colspan=2>글을 써보세요</td>

        </tr>
        <tr>
            <td>이름</td>
            <td><input type="text" name="name" size="20" maxlength="20"></td>
        </tr>
        <tr>
            <td>이메일</td>
            <td><input type="text" name="email" size="20" maxlength="20"></td>
        </tr>
        <tr>
            <td>비번</td>
            <td><input type="text" name="pass" size="20" maxlength="20"></td>
        </tr>
        <tr>
            <td>제목</td>
            <td><input type="text" name="title" size="65" maxlength="20"></td>
        </tr>
        <tr>
            <td>내용</td>
            <td><textarea name="content" cols="70" rows="20"></textarea></td>
        </tr>
        <tr>
            <td colspan=2>
               <input type="submit" value="저장"> &nbsp;
               <input type="reset" value="다시 쓰기"> &nbsp;
               <input type="button" value="목록" onclick="history.back(-1)"> 
            </td>

        </tr>
    </table>
</form>