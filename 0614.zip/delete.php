<?php
    include "db_info.php";
    $query = "DELETE from my_board where  "

?>