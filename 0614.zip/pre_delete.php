<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<form>
    비밀번호 : <input type="password" name = "pass">
    <input type="button" value="확인" id="pw_check">

    <script>
        $("#pw_check").click(function(){

            $.ajax({
                url: 'update.php', // 이 php파일을 이용해서 db에 접근하겠다.
                type: 'post',
                data: $("form").serialize(), // db로 보낼 데이터
                dataType: 'json', // 서버에서 받는 결과 데이터 타입
                success: function (data) { // 전송처리 성공 메서드   
                    // alert(data.name);
                    if (data.count == 1) { //data라는 이름을 가진 객체의 key값이 count인 것의 value가 1일 경우
                        $("#idcheck").val("0"); 
                        $("#description").html("이미 있다").css("color", "red");
                             
                    } else {
                        $("#idcheck").val("1");
                        $("#description").html("사용가능하다").css("color", "blue");
                    }
                },
            });

        });
    </script>
</form>
</body>
</html>





<?php
$id = $_GET['id'];
//$pass = $_POST['pass'];
include "db_info.php";
$query = "SELECT pass from my_board where id = $id"
$rs = mysql_query($query);
$row = mysql_fetch_array($rs);

if ($row[0]==$pass) { //차례로 읽으면 끝나기 때문에(value를 어디로 전송하지 않는 이상), 위 html의 form에서 입력받은 값을 여기 php에서 사용불가. 
                      //사용하려면 ajax사용 필요

//비번이 일치하면 -> delete.php(db에 delete쿼리 전송)로 이동
?>
    <script>
        location.href="delete.php";
    </script>
<?php
}else {
//비번 일치하지 않으면 ->pre_delete.php 로 이동
?>
    <script>
        alert("비번이 일치하지 않습니다.");
        location.href="pre_delete.php";
    </script>

<?php
}

?>