<?php
    include "db_info.php";
    $id = $_GET['id'];
    $query = "SELECT * from my_board where id =$id";
    $result = mysql_query($query,$conn);
    list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view) = mysql_fetch_array($result);
?>

    <table border=1>
        <caption>글보기</caption>
        <tr>
            <td>글쓴이 이름</td><td><?=$name?></td>
        </tr>
        <tr>
            <td>이메일</td><td><?=$email?></td>
        </tr>
        <tr>
            <td>글쓴 날짜</td><td><?=$wdate?></td>
        </tr>
        <tr>
            <td>조회수</td><td><?=$view?></td>
        </tr>
        <tr>
            <td colspan=2><?=$content?>
        </tr>
        <tr>
        <td colspan=2>
                <a href="list.php">목록보기</a>
                <a href="edit.php?id=<?=$id?>">수정하기</a>
                <a href="pre_delete.php?id=<?=$id?>">삭제하기</a>
                <a href="write.php">글쓰기</a>
                
            </td>
        </tr>
       
    </table>



<?


?>