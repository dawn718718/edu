<?php
    include "db_info.php";
    $name=$_POST['name'];
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $title=$_POST['title'];
    $content=$_POST['content'];
    $remoteAddr=$_SERVER['remote_addr'];
    $query = "INSERT into 
    my_board (id,name,email,pass,title,content,wdate,ip,view) 
    values(null,'$name','$email','$pass','$title','$content','now()','$remoteAddr',0)";
    $result = mysql_query($query,$conn);
    if ($result) {
    ?>
        <script>
            alert ("성공적으로 저장되었습니다");
            location.href="list.php";
        </script>
    <?php
    }else {
    ?>
        <script>
        alert ("글이 저장되지 않았습니다. 다시 시도하세요");
        location.href="write.php";
        </script>
    <?
    }


?>