<?php
    include "db_info.php";
    $id = $_GET['id'];
    $name = $_POST['name'];
    $email= $_POST['email'];
    $pass= $_POST['pass'];
    $title= $_POST['title'];
    $content= $_POST['content'];
    $remoteAddr = $_SERVER['remote_addr'];

    $query = "UPDATE my_board set
      name = '$name',
      email = '$email',
     pass= '$pass',
     title= '$title',
     content= '$content',
     wdate= now(),
     ip= '$remoteAddr'  where id=$id";
     
    $result = mysql_query($query);
    if ($result) {
?>
        <script>
            alert("성공적으로 수정되었습니다");
            location.href="list.php";
        </script>
<?php
    }else {

?>
        <script>
            alert("수정에 실패했습니다");
            location.href = "read.php";
        </script>
<?php

    }

     

?>