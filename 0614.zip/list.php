<?php
    include "db_info.php";
    $query = "SELECT * from my_board";
    $result = mysql_query($query,$conn);
    

?>
    <table border = 1>
        <caption>글 목록</caption>
        <tr>
            <td>번호</td>
            <td>제목</td>
            <td>글쓴이</td>
            <td>날짜</td>
            <td>조회수</td>
        </tr>
<?php
while(list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view) = mysql_fetch_array($result)) {
?>
    <tr>
        <td><a href="read.php?id=<?=$id?>"><?=$id?></a></td> <!-- 이렇게 받은건 get으로 보내주므로 read에서 get으로 받아라 -->
        <td><?=$title?></td>
        <td><?=$name?></td>
        <td><?=$wdate?></td>
        <td><?=$view?></td>
    </tr>
<?php
}
?>

    </table>


    <a href="write.php">[글쓰기]</a>

