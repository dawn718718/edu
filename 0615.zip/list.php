<?php
    include "db_info.php";
    $query = "SELECT * from your_board";
    $rs = mysql_query($query,$conn);


?>

<table border=1>

    <tr>
        <td>글번호</td>
        <td>제목</td>
        <td>글쓴이</td>
        <td>날짜</td>
        <td>조회수</td>
    </tr>

<?php
while(list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view)=mysql_fetch_array($rs)){
?>
    <tr>
        <td><a href="read.php?id=<?=$id?>"><?=$id?></a></td>
        <td><?=$title?></td>
        <td><?=$name?></td>
        <td><?=$wdate?></td>
        <td><?=$view?></td>
    </tr>
<?php
}
?>
</table>
<a href="write.php">[글쓰기]</a>

    
<?php
   


?>