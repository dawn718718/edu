<?php
include "db_info.php";
$id = $_GET['id'];
$query = "SELECT * from your_board where id= $id";
$rs = mysql_query($query,$conn);
list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view)=mysql_fetch_array($rs);
?>
<form action="update_editing.php" method="post">
    <input type="hidden" name="id" value="<?=$id?>">
<table>
    <tr>
        <td>제목</td>
        <td><input type="text" name="title" size="60" maxlength="10" value="<?=$title?>"></td>
    </tr>
    <tr>
        <td>글쓴이</td>
        <td><input type="text" name="name" size="40" maxlength="10" value="<?=$name?>"></td>
    </tr>
    <tr>
        <td>이메일</td>
        <td><input type="text" name="email" size="40" maxlength="10" value="<?=$email?>"></td>
    </tr>
    <tr>
        <td>비번</td>
        <td><input type="text" name="pass" size="40" maxlength="10" value="<?=$pass?>"></td>
    </tr>
    <tr>
        <td>내용</td>
        <td><textarea name="content" cols="70" rows="25"><?=$content?></textarea></td>
    </tr>
    <tr>
        <td colspan=2>
            <input type="submit" value="저장">
            <input type="reset" value="다시 쓰기">
            <input type="button" value="취소" onclick="history.back(-1)">
        </td>
    </tr>
</table>
</form>

