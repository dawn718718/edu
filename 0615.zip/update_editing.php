<?php
include "db_info";
$id=$_GET['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$title=$_POST['title'];
$content=$_POST['content'];
$remoteAddr=$_SERVER['REMOTE_ADDR'];

$query = "UPDATE your_board set name='$name', email='$email', pass='$pass', title='$title', content='$content', wdate=now(), ip='$remoteAddr'  where id=$id ";
$rs = mysql_query($query,$conn);
if ($rs) {
?>
    <script>
        alert ("성공적으로 수정했다.");
        location.href="list.php";
    </script>
<?
}else {
?>
    <script>
        alert ("수정에 실패했다.");
        location.href="list.php";
    </script>
<?php
}

?>