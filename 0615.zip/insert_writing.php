<?php
    include "db_info.php";
    
    $name = $_POST['name'];
    $email= $_POST['email'];
    $pass= $_POST['pass'];
    $title= $_POST['title'];
    $content= $_POST['content'];
    $remoteAddr= $_SERVER['REMOTE_ADDR'];

    $query = "INSERT into your_board(name,email,pass,title,content,wdate,ip) 
    values('$name','$email','$pass','$title','$content',now(),'$remoteAddr')";
    echo $query;
    $rs = mysql_query($query,$conn);
    if ($rs) {
?>
<script>
    alert ("글 저장에 성공하였습니다");
    location.href="list.php";
</script>
<?php
    }else {
?>
<script>
    alert ("글 저장에 실패했습니다. 다시 시도해보세요");
    location.href = "write.php";
</script>
<?php
    }


?>