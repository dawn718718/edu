<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="insert_writing.php" method="post">
    <table>
        <tr>
            <td colspan=2>글쓰기</td>
        </tr>
        <tr>
            <td>이름</td>
            <td><input type="text" name="name" size="40" maxlength="10"></td>
        </tr>
        <tr>
            <td>이메일</td>
            <td><input type="text" name="email" size="40" maxlength="10"></td>
        </tr>
        <tr>
            <td>비번</td>
            <td><input type="text" name="pass" size="40" maxlength="10"></td>
        </tr>
        <tr>
            <td>제목</td>
            <td><input type="text" name="title" size="60" maxlength="10"></td>
        </tr>
        <tr>
            <td>내용</td>
            <td><textarea name="content" cols="70" rows="25"></textarea></td>
        </tr>
        <tr>
            <td colspan=2>
                <input type="submit" value="확인">
                <input type="reset" value="다시쓰기">
                <input type="button" value="목록보기" onclick="history.back(-1)">
            </td>
        </tr>
    </table>
</form>    

</body>
</html>

