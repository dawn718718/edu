<?php
    include "db_info.php";
    $id = $_GET['id'];
    $query = "SELECT * from your_board where id = $id";
    $rs = mysql_query($query,$conn);
    list($id,$name,$email,$pass,$title,$content,$wdate,$ip,$view)=mysql_fetch_array($rs);
?>
<table border=1>
    <tr>
        <td colspan=2>게시판</td>
    </tr>
    <tr>
        <td>이름</td>
        <td><?=$name?></td>
    </tr>
    <tr>
        <td>이멜</td>
        <td><?=$email?></td>
    </tr>
    <tr>
        <td>글쓴날짜</td>
        <td><?=$wdate?></td>
    </tr>
    <tr>
        <td>조회수</td>
        <td><?=$view?></td>
    </tr>
    <tr>
        <td>제목</td>
        <td><?=$title?></td>
    </tr>
    <tr>
        <td>내용</td>
        <td><textarea name="content" cols="70" rows="25" readonly><?=$content?></textarea></td>
    </tr>
    <tr>
        <td colspan=2>
            <a href="list.php">목록보기</a>
            <a href="write.php">글쓰기</a>
            <a href="edit.php?id=<?=$id?>">수정</a>
            <a href="delete.php?id=<?=$id?>">삭제</a>
        </td>
    </tr>
</table>


<?php

?>