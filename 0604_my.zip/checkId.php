<?php
$conn = mysql_connect("localhost","root","1111");
mysql_select_db("zdb");
$userid = $_POST['userid'];

if($userid == null){

?>
    <script>
   
        alert ("아이디를 입력해라");
        location.href="checkId.html";
    
    </script>

<?
exit;
}
$query="SELECT count(*) from users where userid='$userid'";
$rs = mysql_query($query,$conn);
$row = mysql_fetch_array($rs);
//아이디 중복체크

if($row[0]==1){
    ?>
    <script>
        alert ("중복된 아이디가 이미 존재한다. 다른거 해라");
        location.href="checkId.html";
    </script>
    <?
    
} else {
    ?>
    <script>
    alert ("사용가능하다");
    location.href="checkId.html";
    document.getElementByid("userid").value = $userid;


    </script>
    <? 
    exit;
}
?>