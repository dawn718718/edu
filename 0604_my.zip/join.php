<?php
    $conn = mysql_connect("localhost","root","1111");
    mysql_select_db("zdb");
    mysql_query("set names utf8");
    $userid = $_POST['userid'];
    $userpw = $_POST['userpw'];
    $name = $_POST['name'];

//
// $conn = mysql_connect("localhost", "root", "1111");
// mysql_query("set names utf8");
// mysql_select_db("zdb");

// $name = $_POST['name'];
// $userid= $_POST['userid'];
// $userpw= $_POST['userpw'];

// $query = "SELECT COUNT(*) FROM users WHERE userid='$userid'";
// $result = mysql_query($query, $conn);
// $row = mysql_fetch_array($result);


    /*아이디 중복체크
    $queryDuple="SELECT count(*) from users where userid='$userid'";
    $rsDuple = mysql_query($queryDuple,$conn);
    $row = mysql_fetch_array($rsDuple);
    
    if($row[0]==1){
        ?>
        <script>
            alert ("중복된 아이디가 이미 존재한다. 다른거 해라");
            location.href="join.html"
        </script>
        <?
        exit;
    } else {
        ?>
        <script>
            alert ("사용 가능한 아이디다. 계속 해라");
            location.href="join.html"
        </script>
        <? 
        exit;
    }
    */
    //Insert
    $query="INSERT INTO users(userid, userpw, name) VALUES('$userid','$userpw','$name')";
    $rs=mysql_query($query,$conn);
    if($rs){
        ?>
        <script>
            alert ("성공적으로 가입되었다. 축하한다");
            location.href="logIn.html";
        </script>
        <?
    } else {
        ?>
        <script>
            alert ("가입에 실패했다. 다시 한번 시도해봐라");
            location.href="join.html";
        </script>
        <?
    }


    

?>