<?php
$conn = mysql_connect("localhost","root","1111");
mysql_select_db("zdb");
$userid = $_POST['userid'];
$userpw = $_POST['userpw'];
$query1="SELECT count(*) FROM users where userid='$userid' AND userpw='$userpw'";
$rs = mysql_query($query1,$conn);
$row = mysql_fetch_array($rs);
if($row[0]==1){
    echo "성공적으로 로그인했따";
} else {
    ?>
    <script>
        alert ("로그인에 실패했다");
        location.href="logIn.html";
    </script>
    <?
}


?>