

<!DOCTYPE html>

<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Elate &mdash; 100% Free Fully Responsive HTML5 Template by FREEHTML5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
		<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
		<meta name="author" content="FREEHTML5.CO" />

		<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
		<link rel="shortcut icon" href="favicon.ico">
		<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Simple Line Icons -->
		<link rel="stylesheet" href="css/simple-line-icons.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Bootstrap  -->
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/style.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		<style>
		.sizeBookCol {
			width:115px;
			height:156px;
			margin: 25px; 
			float:left;
			
		}
		.moreBookButton {
			font-size:15px;
			background-color:#7a7a7a;
			color: black;
			text-decoration:none;
		}
		a {
			text-decoration:none;
		}
		.loginComment {
			text-align:right;
			color:black;
			font-size:17px;
		}
		
		</style>
	</head>

	<body>
		<header role="banner" id="fh5co-header">
			<div class="container">
				<?include("header.php");?>
				<meta charset="utf-8" />
					<?php
					session_start();
					if(!isset($_SESSION['email']) || !isset($_SESSION['username'])) {
						echo "<meta http-equiv='refresh' content='0;url=signin.php'>";
						exit;
					}
					$email = $_SESSION['email'];
					$username = $_SESSION['username'];
					// echo "<p>안녕하세요. $username($email)님</p>";
					// echo "<p><a href='signout.php'>로그아웃</a></p>";
					?>

					<div class="row">
							<div class="col-md-12 loginComment" >안녕하세요. <?=$username.'('.$email.')'?>님 &nbsp
							  <!-- <a href='signout.php' style="text-decoration:none; color:white">로그아웃</a> -->
							  <button class="btn btn-sm" onclick=logout()>Logout</button>
							</div>
					</div>
					<script>
					function logout() {
						location.href="signout.php";
					}
					</script>
			</div>
		</header>
		<!-- 상단 탑 메인 이미지 및 글씨 -->
		<section id="fh5co-home" data-section="home" style="background-image: url(images/full_image_2.jpg);" data-stellar-background-ratio="0.5">
			<div class="gradient"></div>
			<div class="container">
				<div class="text-wrap">
					<div class="text-inner">
						<div class="row">
							<div class="col-md-8 col-md-offset-2">
								<h1 class="to-animate">나만의 책장을 만들어보세요.</h1>
								<h2 class="to-animate">읽었던 책이 잘 기억나지 않나요? 내가 좋아했던 문장, 남기고 싶은 말을 책 정보와 함께 노트로 기록해보세요.  <br> <small>― My Books ― </small></h2>
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="slant"></div>
		</section>

	<!-- 3줄 버튼 (새 책 추가, 내 책장가기, 검색하기) -->
		<section id="fh5co-intro">
			<div class="container">
				<div class="row row-bottom-padded-lg">
					<div class="fh5co-block to-animate" style="background-image: url(images/img_7.jpg);">
						<div class="overlay-darker"></div>
						<div class="overlay" style="border-color: grey"></div>
						<div class="fh5co-text">
							<i class="fh5co-intro-icon icon-bulb"></i>
							<h2>새 책 추가하기</h2>
							<p>네이버 책 데이터베이스를 이용한 책 검색을 통해 원하는 책을 손쉽게 내 책장으로 가져와 관리할 수 있습니다.</p>
							<p><a href="searchBook.php" class="btn btn-primary">Click Me</a></p>
						</div>
					</div>

					<div class="fh5co-block to-animate" style="background-image: url(images/img_8.jpg);">
						<div class="overlay-darker"></div>
						<div class="overlay"  style="border-color: grey"></div>
						<div class="fh5co-text">
							<i class="fh5co-intro-icon icon-wrench"></i>
							<h2>내 책장 보기</h2>
							<p>내 책장에 있는 책들을 갤러리 형식으로 보여주어, 내가 읽은 책에 대한 정보 및 나의 개인적인 기록들을 둘러보고 수정할 수 있습니다. </p>
							<p><a href="showBookShelf.php" class="btn btn-primary">Click Me</a></p>
						</div>
					</div>
					<div class="fh5co-block to-animate" style="background-image: url(images/img_10.jpg);">
						<div class="overlay-darker"></div>
						<div class="overlay" style="border-color: grey"></div>
						<div class="fh5co-text">
							<i class="fh5co-intro-icon icon-rocket"></i>
							<h2>통계</h2>
							<p>내가 읽은 책의 권수, 책을 읽은 날수, 오디오북의 갯수 등 내가 지금까지 읽은 책에 대한 데이터를 종합적으로 확인할 수 있습니다.</p>
							<p><a href="#" class="btn btn-primary">Click Me</a></p>
						</div>
					</div>
				</div>
				<!-- <div class="row watch-video text-center to-animate">
					<span>Watch the video</span>

					<a href="https://vimeo.com/channels/staffpicks/93951774" class="popup-vimeo btn-video"><i class="icon-play2"></i></a>
				</div> -->
			</div>
		</section>

		<!-- 책 갤러리 -->
		<section id="fh5co-work" data-section="work">
			<div class="container">
				<div class="row">
					<div class="col-md-12 section-heading text-center">
						<h2 class="to-animate">나의 책장</h2>
						<div class="row">
							<div class="col-md-8 col-md-offset-2 subtext to-animate">
								<h3>가장 최근에 추가한 책을 순서대로 보여줍니다. </h3>
							</div>
						</div>
					</div>
				</div>

					<!-- 루프 돌릴 갤러리 column 단위 시작 / 주의: 9개만 가져와야함!-->
					<div class="row row-bottom-padded-sm" id="SearchR">
							<?php
								include "conn.php";
								$query="SELECT * from books order by book_reg_date desc limit 35";
								$rs=mysql_query($query,$conn);
								$i=0;
								while(list($isbn,$email,$cover_path,$title,$writer,$publisher,$pub_date,
								$read_date,$audio_path,$rem_words,$comments,$moreinfo,$book_reg_date)=mysql_fetch_array($rs)){;
		
							?>
								<div class="sizeBookCol">
									<a href="OpenBookDetails.php?isbn=<?=$isbn?>">
										<div>
											<img src='<?=$cover_path?>' alt='<?=$title?>' width="115" height="156" >
										</div>
									</a>
								</div> 
							<?php
								}
							?>
		
					</div> 
					<!-- 갤러리 column 단위 끝-->
					<div class="row">
						<a href="showBookShelf.php"><button type="button" class="btn btn-primary col-md-4 " style="margin-left:20px;font-size:17px;" ><stron>책 더보기</strong></button></a>
					</div>
			
			</div>
		</section>


	
		<!-- 통계 -->
		<section id="fh5co-counters" style="background-image: url(images/full_image_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="fh5co-overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-12 section-heading text-center to-animate">
						<h2>내 책에 관한 기록</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-briefcase to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="89" data-speed="5000" data-refresh-interval="50">89</span>
							<span class="fh5co-counter-label">읽은 책 수</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-code to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="2343409" data-speed="5000" data-refresh-interval="50">2343409</span>
							<span class="fh5co-counter-label">읽은 페이지 수</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-cup to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="1302" data-speed="5000" data-refresh-interval="50">1302</span>
							<span class="fh5co-counter-label">책 읽은 날수</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="fh5co-counter to-animate">
							<i class="fh5co-counter-icon icon-people to-animate-2"></i>
							<span class="fh5co-counter-number js-counter" data-from="0" data-to="52" data-speed="5000" data-refresh-interval="50">52</span>
							<span class="fh5co-counter-label">오디오 북 수</span>
						</div>
					</div>
				</div>
			</div>
		</section>

	
		<footer id="footer" role="contentinfo">
			<a href="#" class="gotop js-gotop"><i class="icon-arrow-up2"></i></a>
			<div class="container">
				<div class="">
					<div class="col-md-12 text-center">
						<p>&copy; MyBooks. All Rights Reserved. <br>Created by <a href="http://freehtml5.co/" target="_blank">김재연</a></p>
						
					</div>
				</div>
				
			</div>
		</footer>
		


	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Counter -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>


	<!-- For demo purposes only styleswitcher ( You may delete this anytime ) -->
	<script src="js/jquery.style.switcher.js"></script>
	<script>
		$(function(){
			$('#colour-variations ul').styleSwitcher({
				defaultThemeId: 'theme-switch',
				hasPreview: false,
				cookie: {
		          	expires: 30,
		          	isManagingLoad: true
		      	}
			});	
			$('.option-toggle').click(function() {
				$('#colour-variations').toggleClass('sleep');
			});
		});
	</script>
	
	<!-- Main JS (Do not remove) -->
	<script src="js/main.js"></script>

	</body>
</html>


