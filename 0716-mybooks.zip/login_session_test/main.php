<!DOCTYPE html>
<meta charset="utf-8" />
<div>여기는 홈피 나라입니다.</div>
<?php
session_start();
if(!isset($_SESSION['email']) || !isset($_SESSION['username'])) {
	echo "<meta http-equiv='refresh' content='0;url=login.php'>";
	exit;
}
$email = $_SESSION['email'];
$username = $_SESSION['username'];
echo "<p>안녕하세요. $username($email)님</p>";
echo "<p><a href='logout.php'>로그아웃</a></p>";
?>