<?php
include "../conn.php";
if(!isset($_POST['email']) || !isset($_POST['pwd'])) exit;
$email = $_POST['email'];
$pwd = $_POST['pwd'];
// $members = [
//         'user1'=>['pw'=>'pw1', 'name'=>'김일구'],
//         'user2'=>['pw'=>'pw2', 'name'=>'박이팔'],
//         'user3'=>['pw'=>'pw3', 'name'=>'최삼칠'],
// ]; 
$sql = "SELECT email,username,pwd from users where email='$email'";
$result= mysql_query($sql,$conn);
$row = mysql_fetch_array($result);

if($row==null){
    $msg = "아이디를 찾을 수 없습니다.";
}else {
    if($row[2] != $pwd ) {
        $msg = "비밀번호가 일치 하지 않습니다.";
    }else {
        $msg = "로그온 성공";
        session_start();
        $_SESSION['email'] = $row[0];
        $_SESSION['username'] = $row[1];

    }
}
mysql_close($conn);
?>
<script>
    alert('<?=$msg?>');
    location.href="main.php";
</script>


