<?php
    $conn=mysql_connect("localhost","root","1111");
    mysql_select_db("mybooks");
    mysql_query("set names utf8");

    // $conn=mysql_connect("localhost","dawn718","d10jkfteck");
    // mysql_select_db("dawn718");
?>