<?php
    $conn=mysql_connect("localhost","root","1111");
    mysql_select_db("greendb");
    mysql_query("set names utf8");

?>