<?php
    session_start();
    session_unset(); // 세션저장된 변수를 모두 삭제
    session_destroy(); // 세션 종료
?>