<?php
echo $_COOKIE['php'];

?>