<?
    session_start();
    $_SESSION['userid'] = "hslim";
    

    echo $_SESSION['messag'];
    
    echo "<p>";
    echo "PHPSESSID=". session_id();
?>