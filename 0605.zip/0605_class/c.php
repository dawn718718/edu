<?
    $result = setcookie("php", "Cool~", time() + 60, "/");
    if($result){
        echo "쿠키 생성 완료";
    }else{
        echo "쿠키 생성 실패";
    }
?>