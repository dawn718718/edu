<?php

session_start();
$_session['message']="welcome";

?>

<a href = "g.php">이동</a>