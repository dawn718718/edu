<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup core CSS file -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Jquery src -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<!-- Magnific javascript -->
	<script src="./jquery.magnific-popup.js"></script>
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<!-- Flaticons  -->
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

    
</head>
<body>
    <div class="auto_input">
        <h2>검색하기</h3>
        <form method="POST" action="goApiNaver.php">
            <input class="search_box" placeholder="네이버 책 정보를 자동으로 가져옵니다" type="search" id="keyword" name="keyword">
            <input class="search_button" type="submit" id="goSearch" value="검색">
        </form>
    </div>
    

    <script>
        //$.get(url,data,callback함수);
        //$.get(url,callback함수) : 전달할 데이터가 없을 경우
        $(document).ready(function () {
            $("#goSearch").click(function () {
                $.ajax({
                    url: 'goApiNaver.php', //전송할 서버주소
                    type: 'get', //전송타입 (메쏘드) - 디폴트임.생략가능
                    async: true, //비동기여부 - 디폴트임.생략가능
                    data: { key: '사랑' }, //서버로 전송하는 데이터
                    dataType: 'json',
                    timeout: 10000,//서버에서 받는 결과 데이터 타입
                    success: function (data) {
                            for (var i=0; i<12; i++) {
                                document.write("북커버:" + "<a href='viewDetailBook.php?isbn=#'>" + "<img src="+data->items[i]->image+">" + "</a>" + "책제목: " + data->items[i]->title + "저자:" + data->items[i]->author +"<br><hr>");
                            };
                    },
                    error: function (req, status, error) {//전송 처리 에러 메쏘드
                        // alert(req.responseText);
                        // alert(status);
                        // alert(error);
                    },
                    complete: function () {//성공 or 실패 처리 후 호출되는 메써드
                        // alert("complete");
                    }
                });


            });
        });
    </script>

</body>
</html>