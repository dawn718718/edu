<?php
    include "conn.php";
    $username = $_POST["username"];
    $email = $_POST["email"];
    $pwd = $_POST["pwd"];

    $sql="SELECT count(*) from users where email='$email'";
    $rs1=mysql_query($sql);
    $row=mysql_fetch_array($rs1);
    if($row[0]=1){
    ?>
    <script>
        alert("이미 존재하는 이메일입니다.");
        location.href="";
    </script>
    <?
    }

    //사용자 입력값 DB에 입력
    $sql ="INSERT into users(username,email,pwd) values('$username','$email','$pwd')";
    $rs2 = mysql_query($sql);
    if($rs2){
?>
    <script>
        alert("성공적으로 가입되었습니다. 확인을 누르면 로그인창으로 이동합니다.");
        location.href="signin.html"
    </script>
<?php 

}
?>
