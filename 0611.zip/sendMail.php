<?
use PHPMailer\PHPMailer\PHPMailer;
include "accountMail.php";		// 지메일 계정정보

include '../common/PHPMailer/src/PHPMailer.php';
include '../common/PHPMailer/src/Exception.php';
include '../common/PHPMailer/src/SMTP.php';

    function send_email(){
        global $gmail_id;
        global $gmail_pwd;

        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPDebug = 2;
        $mail->CharSet="UTF-8";
		$mail->Host = "smtp.gmail.com";               // email 보낼때 사용할 서버를 지정
		$mail->SMTPAuth = true;
		$mail->Port = 587;
		$mail->SMTPSecure = "tls";  
		$mail->Username   = $gmail_id;                // Gmail 계정
		$mail->Password   = $gmail_pwd;               // 패스워드
		$mail->SetFrom($gmail_id, "관리자");  		  // 보내는 사람 email 주소와 표시될 이름 (표시될 이름은 생략가능)
		$mail->AddAddress("dawn718@naver.com"); 		// 받을 사람 email 주소와 표시될 이름 (표시될 이름은 생략가능)
		$html = "<table border=1><tr><td>이름</td><td>비번</td></tr><tr><td>홍길동</td><td>1234</td></tr></table>";
		
		$mail->isHTML(true);
		$mail->Subject = "가입안내메일";               // 메일 제목
		$mail->MsgHTML($html);                        // 메일 내용 (HTML 형식도 되고 그냥 일반 텍스트도 사용 가능함)
		
		$mail->Send();
    }
    send_email();

?>

