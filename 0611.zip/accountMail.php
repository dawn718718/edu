<?php
    $gmail_id = "jen24june@gmail.com";
    $gmail_pwd = "g!0jkfteck";

?>