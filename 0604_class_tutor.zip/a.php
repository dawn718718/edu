<?
    include "db_info.php";
    
?>