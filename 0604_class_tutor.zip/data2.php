<?php
    header("Content-Type:application/json");
    $conn = new mysqli("localhost", "root", "hslim", "zdb");
    
    if($conn->connect_errno)
        die('Connect error:'.$conn->connect_error);    
    mysqli_set_charset($conn, 'utf8');
    
    $userid = $_POST['userid'];
    $result = $conn->query("select count(*) as count from users where userid='$userid'");
    $row = $result->fetch_array();
    echo json_encode($row);

?>